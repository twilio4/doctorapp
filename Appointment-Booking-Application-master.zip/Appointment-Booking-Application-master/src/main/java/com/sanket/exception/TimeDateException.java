package com.sanket.exception;

public class TimeDateException extends Exception {
	
	public TimeDateException() {
	}
	
	public TimeDateException(String msg) {
		super(msg);
	}

}
