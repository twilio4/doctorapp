package com.sanket.exception;

public class PasswordException extends Exception{
	
	public PasswordException(){
		
	}
	
	public PasswordException(String msg){
		super(msg);
	}
	

}
