package com.sanket.exception;

public class DoctorException extends Exception {
	
	public DoctorException() {
	}
	
	public DoctorException(String msg) {
		
		super(msg);
		
	}

}
